package com.zodiaku.myzodiak;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
TextView tanggal,zodiaktv;
Button btnTanggal;
    Calendar myCalendar;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tanggal= findViewById(R.id.tvTanggal);
        btnTanggal=findViewById(R.id.btnOpenDatePicker);
        zodiaktv = findViewById(R.id.zodiaktv);

        myCalendar = Calendar.getInstance();

        btnTanggal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        myCalendar.set(Calendar.YEAR, year);
                        myCalendar.set(Calendar.MONTH, month);
                        myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                        String formatTanggal = "dd-MM-yyyy";

                        SimpleDateFormat sdf = new SimpleDateFormat(formatTanggal);
                        tanggal.setText("Kamu memilih tanggal : " + sdf.format(myCalendar.getTime()));
                        String date = sdf.format(myCalendar.getTime());
                        progressDialog = new ProgressDialog(MainActivity.this);
                        progressDialog.setMessage("Loading....");
                        progressDialog.show();

                        /*Create handle for the RetrofitInstance interface*/
                        ReadZodiak(date,new FirebaseSuccessReadListener() {
                            @Override
                            public void onDataFound(Zodiak zodiak) {
                               zodiaktv.setText("Zodiak Anda : "+zodiak.getZodiak());
                            }
                        });


                    }
                },
                        myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


    }
    public interface FirebaseSuccessReadListener {

        void onDataFound(Zodiak zodiak);

    }

    public void ReadZodiak (String date,final FirebaseSuccessReadListener datafetch){
        GetService service = ApiClient.getRetrofitInstance().create(GetService.class);
        Call<ZodiakData> call;
        call = service.getData("ican",date);
        call.enqueue(new Callback<ZodiakData>() {
            @Override
            public void onResponse(Call<ZodiakData> call, Response<ZodiakData> response) {
                Log.d("hello",response.body().getData().getZodiak());
                datafetch.onDataFound(response.body().getData());
                progressDialog.hide();
            }

            @Override
            public void onFailure(Call<ZodiakData> call, Throwable t) {
                Log.d("hello",t.getMessage());
                progressDialog.hide();
            }
        });
    }
    }


