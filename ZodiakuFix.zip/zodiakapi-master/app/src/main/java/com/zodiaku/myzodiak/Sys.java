package com.zodiaku.myzodiak;

import com.google.gson.annotations.SerializedName;

public class Sys {
    @SerializedName("sys")
    private sysdata sys = null;

    public sysdata getSys() {
        return sys;
    }

    public void setSys(sysdata sys) {
        this.sys = sys;
    }
}
