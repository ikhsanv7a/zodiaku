package com.zodiaku.myzodiak;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class WeatherData {
    @SerializedName("main")
    private List<Weather> weathers;

    public List<Weather> getWeathers() {
        return weathers;
    }

    public WeatherData(List<Weather> weathers) {
        this.weathers = weathers;
    }
}
