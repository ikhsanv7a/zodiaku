package com.zodiaku.myzodiak;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Weather {
    @SerializedName("timezone")
    private String timezone;
    @SerializedName("id")
    private String id;
    @SerializedName("name")
    private String name;
    @SerializedName("cod")
    private String cod;
    @SerializedName("sys")
    private List<Sys> sys;


    public Weather(){

    }

    public Weather(String timezone, String id, String name, String cod,List<Sys> sys) {
        this.timezone = timezone;
        this.id = id;
        this.name = name;
        this.cod = cod;
        this.sys = sys;
    }

    public List<Sys> getSys() {
        return sys;
    }

    public String getTimezone() {
        return timezone;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCod() {
        return cod;
    }
}
