package com.zodiaku.myzodiak;

import com.google.gson.annotations.SerializedName;

public class ZodiakData {
    @SerializedName("data")
    private Zodiak data;

    public ZodiakData(Zodiak data) {
        this.data = data;
    }

    public Zodiak getData() {
        return data;
    }
}
