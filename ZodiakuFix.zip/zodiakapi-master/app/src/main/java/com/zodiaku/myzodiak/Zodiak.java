package com.zodiaku.myzodiak;

import com.google.gson.annotations.SerializedName;

public class Zodiak {
    @SerializedName("temp")
    private String nama;
    @SerializedName("lahir")
    private String lahir;
    @SerializedName("usia")
    private String usia;
    @SerializedName("ultah")
    private String ultah;
    @SerializedName("zodiak")
    private String zodiak;


    public Zodiak(){

    }

    public Zodiak(String nama, String lahir, String usia, String ultah, String zodiak) {
        this.nama = nama;
        this.lahir = lahir;
        this.usia = usia;
        this.ultah = ultah;
        this.zodiak = zodiak;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getLahir() {
        return lahir;
    }

    public void setLahir(String lahir) {
        this.lahir = lahir;
    }

    public String getUsia() {
        return usia;
    }

    public void setUsia(String usia) {
        this.usia = usia;
    }

    public String getUltah() {
        return ultah;
    }

    public void setUltah(String ultah) {
        this.ultah = ultah;
    }

    public String getZodiak() {
        return zodiak;
    }

    public void setZodiak(String zodiak) {
        this.zodiak = zodiak;
    }
}
