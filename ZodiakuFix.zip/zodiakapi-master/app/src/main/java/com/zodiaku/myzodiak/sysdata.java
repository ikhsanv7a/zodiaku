package com.zodiaku.myzodiak;

import com.google.gson.annotations.SerializedName;

public class sysdata {

    @SerializedName("type")
    private String type;
    @SerializedName("id")
    private String id;
    @SerializedName("country")
    private String country;
    @SerializedName("sunrise")
    private String sunrise;
    @SerializedName("sunset")
    private String sunset;

    public sysdata(String type, String id, String country, String sunrise, String sunset) {
        this.type = type;
        this.id = id;
        this.country = country;
        this.sunrise = sunrise;
        this.sunset = sunset;
    }

    public String getType() {
        return type;
    }

    public String getId() {
        return id;
    }

    public String getCountry() {
        return country;
    }

    public String getSunrise() {
        return sunrise;
    }

    public String getSunset() {
        return sunset;
    }
}
