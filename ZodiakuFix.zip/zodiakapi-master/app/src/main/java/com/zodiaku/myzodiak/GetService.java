package com.zodiaku.myzodiak;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface GetService {
    @GET("/macros/exec?service=AKfycbw7gKzP-WYV2F5mc9RaR7yE3Ve1yN91Tjs91hp_jHSE02dSv9w&")
    Call<ZodiakData> getData (@Query("nama") String nama,@Query("tanggal") String tanggal);
}
